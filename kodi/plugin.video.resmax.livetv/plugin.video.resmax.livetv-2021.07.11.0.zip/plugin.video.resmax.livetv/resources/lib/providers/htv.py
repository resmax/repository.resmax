# -*- coding: utf-8 -*-

import requests
from resources.lib.utils import util
#from resources.lib.utils.rm_requests import Request
from bs4 import BeautifulSoup4

class Htv:
    
    def __init__(self, channel):

        if channel == 'htv7':
            self.channel_url = 'https://hplus.com.vn/xem-kenh-htv7-hd-256.html'
        elif channel == 'htv9':
            self.channel_url = 'https://hplus.com.vn/xem-kenh-htv9-hd-2667.html'
        
        self.s = requests.Session()

        self.header = {
            'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0',
            'Accept-Language': 'en-US,en;q=0.5',
            'Origin': 'https://hplus.com.vn',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Referer': 'https://hplus.com.vn/'
        }

        self.s.headers.update(self.header)


    def get_link_with_token(self):
        util.log('Getting link with token...')

        response = self.s.get(self.channel_url)
        soup = BeautifulSoup(response, "html.parser")

        inputs = soup.select('input')

        for inp in inputs:
            if 'playlist' in inp.get('value'):
                link_with_token = inp.get('value')
                util.log(link_with_token)
                return link_with_token



    def get_link_with_signKey(self):
        util.log('Getting link with signKey...')

    def patch_playlist_with_signKey(self):
        util.log('Patching playlist with signKey...')

    def get_playlist_with_uri(self):
        util.log('Getting playlist with uri...')



        # return this playlist with header patch

        return 'playlist'



