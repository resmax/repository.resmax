# -*- coding: utf-8 -*-

import requests

class Request():

    def __init__(self, session=True, headers=None, cookies=None):
        

