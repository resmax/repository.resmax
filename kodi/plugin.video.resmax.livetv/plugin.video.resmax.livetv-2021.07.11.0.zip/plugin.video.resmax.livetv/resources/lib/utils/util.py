# -*- coding: utf-8 -*-

import time, sys, codecs, re, random, math, pickle

import xbmc

from selenium.webdriver import Firefox
from selenium.webdriver.firefox.options import Options as Options
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile

from selenium.webdriver import DesiredCapabilities

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support import expected_conditions as EC

def get_webdriver(url):

    options = Options()

    profile = FirefoxProfile()
    #profile = FirefoxProfile('/home/astroboy/.mozilla/firefox/my-default')
    profile.set_preference('devtools.jsonview.enabled', False)
    profile.set_preference("dom.webdriver.enabled", False)
    profile.set_preference('useAutomationExtension', False)
    profile.set_preference('excludeSwitches', 'enable-automation')
    profile.update_preferences()
    
    desired = DesiredCapabilities.FIREFOX

    #user_agent = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0'
    #print user_agent
    user_agent = get_user_agent('mobile')

    options.add_argument('--headless')
    options.add_argument('--mute-audio')
    options.add_argument('--disable-web-security') # to get blob data
    options.add_argument('--allow-running-insecure-content')
    options.add_argument('user-agent=%s' %user_agent)
    options.add_argument('--disable-gpu') # windows only
    options.add_argument('--no-sandbox') # by pass OS security model
    options.add_argument('--disable-extensions')
    options.add_argument('--disable-logging')
    options.add_argument('start-maximized')
    options.add_argument('--diable-dev-shm-usage')
    options.add_argument('--diable-plugins-discovery')
    options.add_argument('--disable-blink-featuresi=AutomationControlled')
    options.add_argument('--disable-blink-features')
    
    #options.add_argument('--profile-directory=Default')
    #options.add_argument('disable-infobars') # chrome only
    #driver = webdriver.Chrome(chrome_options=options, executable_path="/usr/bin/chromedriver")
    #driver = webdriver.Firefox(options=options, service_log_path='/dev/null') 
    
    driver = Firefox(options=options, firefox_profile=profile, desired_capabilities=desired, service_log_path='/dev/null')
    
    driver.implicitly_wait(2)   # wait for webdriver ready
    driver.get(url)  # get google translate with source | target lang pair

    return driver

def get_element(driver, xpath):

    MAX_WAIT = 5
    LOOP = 3

    element = None

    for i in range(1, LOOP+1):
        try:
            element = WebDriverWait(driver, MAX_WAIT*i).until(EC.presence_of_element_located((By.XPATH, xpath)))
            print('Element found.')
            break

        except TimeoutException:
            print('Loading took too much time. Reloading ', i, ' time(s) out of ', LOOP)

    return element

def get_elements(driver, xpath):

    MAX_WAIT = 5
    LOOP = 3

    elements = None

    for i in range(1, LOOP+1):
        try:
            elements = WebDriverWait(driver, MAX_WAIT*i).until(EC.presence_of_all_elements_located((By.XPATH, xpath)))
            print('Elements found.')
            break

        except TimeoutException:
            print('Loading took too much time. Reloading ', i, ' time(s) out of ', LOOP)

    return elements

# get text
# jquery version:
def get_text_excluding_children_jq(driver, element):
    return driver.execute_script("""
    return jQuery(arguments[0]).contents().filter(function() {
        return this.nodeType == Node.TEXT_NODE;
    }).text();
    """, element)

# javascript version:
def get_text_excluding_children_js(driver, element):
    return driver.execute_script("""
    var parent = arguments[0];
    var child = parent.firstChild;
    var ret = "";
    while(child) {
        if (child.nodeType === Node.TEXT_NODE)
            ret += child.textContent;
    child = child.nextSibling;
    }
    return ret;
    """, element)

# serialize a list of text to file for later use
def dump_list_to_file(file_path, list_of_text):
    with codecs.open(file_path, 'wb') as f:
        pickle.dump(list_of_text, f)
    
    return None

def load_list_from_file(file_path):
    with codecs.open(file_path,'rb') as f:
        itemlist = pickle.load(f)
    
    return itemlist

def write_text_to_file(file_path, text):
    with codecs.open(file_path, 'w', 'utf-8') as f:
        f.write(text)
    
    return None

def read_text_from_file(file_path):
    lines = []
    with codecs.open(file_path, 'r', 'utf-8') as f:
        for line in f:
            lines.append(line)

    return lines
 
def get_user_agent(excluded_keys): # return random user agent

    user_agents = { 'firefox':
                    [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0',       # Windows
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:70.0) Gecko/20100101 Firefox/70.0',   # Mac
                    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:73.0) Gecko/20100101 Firefox/73.0',         # Linux 64
                    'Mozilla/5.0 (X11; Linux i686; rv:71.0) Gecko/20100101 Firefox/71.0',                   # Linux 32
                    'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0', # windows
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0', # mac
                    'Mozilla/5.0 (Windows NT 6.1; rv:73.0) Gecko/20100101 Firefox/73.0', # win
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:79.0) Gecko/20100101 Firefox/79.0', # mac
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:82.0) Gecko/20100101 Firefox/82.0', # mac
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:81.0) Gecko/20100101 Firefox/81.0', # win
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:78.0) Gecko/20100101 Firefox/78.0', # mac
                    'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', # win
                    'Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0', # win
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:81.0) Gecko/20100101 Firefox/81.0' # win
                    ],
                   'chrome':
                    [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36',  # Windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36', # windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', # windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', # windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', # windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', # windows
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', # windows
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36', # Mac
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36', # Linux 64
                    'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36', # Linux 32
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', # win
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36', # win
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', # mac
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', # mac
                    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', # win
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.192 Safari/537.36', # mac
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36' # mac
                    ],
                   'mobile':
                    [
                    'Mozilla/5.0 (Android 10; Mobile; LG-M255; rv:68.0) Gecko/68.0 Firefox/68.0',            # Android
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_1_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.1 Mobile/15E148 Safari/604.1', # mac
                    'Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19',    # Android
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.2 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (Linux; Android 6.0.1; RedMi Note 5 Build/RB3N5C; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.91 Mobile Safari/537.36', # Android
                    'Mozilla/5.0 (Linux; Android 9; SM-G960F Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.157 Mobile Safari/537.36', # Android
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/79.0.3945.73 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/87.0.4280.77 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBDV/iPhone11,8;FBMD/iPhone;FBSN/iOS;FBSV/13.3.1;FBSS/2;FBID/phone;FBLC/en_US;FBOP/5;FBCR/]', # facebook app
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/80.0.3987.95 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (Linux; Android 8.0.0; SM-G930F Build/R16NW; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.157 Mobile Safari/537.36', # Android
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 13_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/83.0.4103.88 Mobile/15E148 Safari/604.1', # iOS
                    'Mozilla/5.0 (Linux; Android 6.0.1; SM-J700M Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', # Android
					'Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19' # Android
                    ]
                 }


    remaining_user_agents = {x: user_agents[x] for x in user_agents if x not in excluded_keys}
    
    my_ua = random.choice(remaining_user_agents[random.choice(list(remaining_user_agents))])    # random key, random value

    print(my_ua)
    return my_ua

def get_time_seconds(time_string):

    total_seconds = sum(x * int(t) for x, t in zip([3600, 60, 1], time_string.split(":")))

    return total_seconds

def login(driver):

    MAX_WAIT = 6

    #profiles = [('porcupines.tv','a***1****')]

    rand_id, rand_key  = random.choice(profiles)

    sign_element = get_element(driver, '//a[text()="Sign in"]')
    sign_element.click()
    delay(MAX_WAIT)

    id_element = get_element(driver, '//input[@id="identifierId"]')
    id_element.send_keys(rand_id)

    id_next_btn = get_element(driver, '//div[@id="identifierNext"]')
    id_next_btn.click()
    delay(MAX_WAIT)


    key_element = get_element(driver, 'input[@type="password"][@aria-label="Enter your password"]')
    key_element.send_keys(rand_key)

    key_next_btn = get_element(driver, '//div[@id="passwordNext"]')
    key_next_btn.click()
    delay(MAX_WAIT)

    return driver

def delay(n):

    time.sleep(random.randint(2, n))

    return None

def log(message):

    xbmc.log('***********************************************')
    xbmc.log(message)
    xbmc.log('***********************************************')
