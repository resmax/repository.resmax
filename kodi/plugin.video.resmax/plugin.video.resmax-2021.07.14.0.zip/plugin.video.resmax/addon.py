# -*- coding: utf-8 -*-

import sys
from urllib.parse import parse_qsl
from resources.lib import Menu

# Construct a dict for plugin parameters                                                        
params = dict(parse_qsl(sys.argv[2].replace('?','')))

print(params)

# Define basic variables passing along plugin parameters
action = params.get('action')

if action == None:
    Menu.root()
elif action == 'tv':
    Menu.tv()
