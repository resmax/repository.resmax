# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin

class Menu():


    def __init__(self):
    
        # list of menu items
        items = []

        self.addon_url = sys.argv[0]
        self.addon_handle = int(sys.argv[1])

        # form a menu item:
        self.tv_menu = xbmcgui.ListItem('TV')
        self.tv_menu_url = '{0}?action=None'.format(self.addon_url)
        is_folder = True
        items.append((search_item_url, search_item, is_folder))

    def add_menu_items(items):
        xbmcplugin.addDirectoryItems(self.handle, items, len(items))
        #xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.setContent(_handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle)
        #xbmc.executebuiltin('Container.SetViewMode(500)')
