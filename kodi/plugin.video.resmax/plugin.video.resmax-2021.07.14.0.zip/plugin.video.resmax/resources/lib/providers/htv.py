# -*- coding: utf-8 -*-

import re
import requests
import json
from resources.lib.utils import util
#from resources.lib.utils.rm_requests import Request
from bs4 import BeautifulSoup

import xbmcvfs
import xbmcaddon
from urllib.parse import urlencode

class Htv:
    
    def __init__(self, channel):

        if channel == 'htv7':
            self.channel_url = 'https://hplus.com.vn/xem-kenh-htv7-hd-256.html'
        elif channel == 'htv9':
            self.channel_url = 'https://hplus.com.vn/xem-kenh-htv9-hd-2667.html'
        
        self.s = requests.Session()

        self.header = {
            'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0',
            'Accept-Language': 'en-US,en;q=0.5',
            'Origin': 'https://hplus.com.vn',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Referer': 'https://hplus.com.vn/'
        }

        self.s.headers.update(self.header)

        self.base_url = ''
        self.signKey_0 = ''
        self.signKey_1 = ''
        self.did = ''
        self.decrypt_key = ''
        self.playlist = []


    def get_link_with_token(self):
        util.log('Getting link with token...')

        response = self.s.get(self.channel_url)

        #print(response.content)
        soup = BeautifulSoup(response.content, "html.parser")

        inputs = soup.find_all('input')

        for inp in inputs:
            #print(inp)
            if u'link-live' == inp.get('id'):
                link_with_token = inp.get('value')
                #util.log(link_with_token)
                return link_with_token

    def get_link_with_signKey(self, link_with_token):
        util.log('Getting link with signKey...')

        u = 'https://hplus.com.vn/content/getlinkvideo/'

        h = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': self.channel_url,
        }

        data = {
            'url': link_with_token,
            'type': '1',
            'is_mobile': '0',
            'csrf_test_name': ''
        }
        
        self.s.headers.update(h) # cookies was preserved in session

        #print(self.s.headers)

        r = self.s.post(u, data=data)

        #print(r.text)
        return r.text

    def patch_playlist_with_signKey(self, link_with_signKey):
        util.log('Patching playlist with signKey...')

        p = re.compile(r"(.*)playlist\.m3u8\?signKey=(.*)")
        self.base_url, self.signKey_1 = p.findall(link_with_signKey)[0]

        #util.log('base_url:'+ self.base_url)
        #util.log('signKey_1:' + self.signKey_1)

        #line_1 = '#EXTM3U'
        #line_2 = '#EXT-X-VERSION:3'
        #line_3 = '#EXT-X-STREAM-INF:BANDWIDTH=1780598,RESOLUTION=1920x1080,CODECS="avc1.640028,mp4a.40.2"'
        #line_4 = self.base_url + 'HTV-ABR/HTV7-HD-1080p/chunks.m3u8?signKey=' + self.signKey_1
        #line_5 = '#EXT-X-STREAM-INF:BANDWIDTH=1588698,RESOLUTION=1280x720,CODECS="avc1.64001f,mp4a.40.2"'
        #line_6 = self.base_url + 'HTV-ABR/HTV7-HD-720p/chunks.m3u8?signKey=' + self.signKey_1
        #line_7 = '#EXT-X-STREAM-INF:BANDWIDTH=584681,RESOLUTION=640x360,CODECS="avc1.64001e,mp4a.40.2"'
        line_8 = self.base_url + 'HTV-ABR/HTV7-HD-360p/chunks.m3u8?signKey=' + self.signKey_1

        #playlist_with_signKey = [line_1, line_2, line_7, line_8]
        #print(playlist_with_signKey)
        #util.log(line_8)

        return line_8

    def get_playlist_with_uri(self, line_8):
        util.log('Getting playlist with uri...')

        h = {
            'TE': 'Trailers'
        }
    
        self.s.headers.update(h) # cookies was preserved in session
        r = self.s.get(line_8)

        #print(r.text)

        lines = r.text.split('\n')

        for line in lines:
            #print(line)
            if 'URI' in line:
                p = re.compile(r'signKey=(.*)\"')
                self.signKey_0 = p.findall(line)[0]
            if len(line) > 0 and line[0] != '#':
                line = self.base_url + line

            if len(line) > 0: 
                self.playlist.append(line)

        #print(self.playlist)

        #write to file in userdata:

        __addon__ = xbmcaddon.Addon(id='plugin.video.resmax.livetv')
        __addondir__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile').encode('utf-8'))

        #print(__addondir__)
        playlist_path = __addondir__ + 'htv7.360p.playlist.m3u8'
        util.write_text_to_file(playlist_path, '\n'.join(self.playlist))

        header_patch = {
            'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Origin': 'https://hplus.com.vn',
            'Referer': 'https://hplus.com.vn/'
        }
        
        # return this playlist with header patch
        ret = playlist_path + '|%s' % urlencode(header_patch)
        #print(ret)
        return ret

